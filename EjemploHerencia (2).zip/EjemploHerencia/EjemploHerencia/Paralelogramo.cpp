#include "stdafx.h"
#include "Paralelogramo.h"
