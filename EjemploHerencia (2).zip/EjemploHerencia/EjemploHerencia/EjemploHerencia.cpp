// EjemploHerencia.cpp : Defines the entry point for the console application.
// Emanuel Romero 

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "conio.h"
#include "Paralelogramo.h"

using namespace std;

int main(void) {
   Rectangulo Rect;
 
   int base, altura; 
   Rect.setWidth(5);
   Rect.setHeight(7);

   // Muestra el �rea de un rectangulo
   cout << "Total area: " << Rect.getArea() << endl;
   Paralelogramo jose; 
   

    
   cout << "Ingrese la base: " << endl; 
   cin >> base; 
   cout << "Ingrese la altura: " << endl; 
   cin >> altura; 
   jose.setHeight(base); 
   jose.setWidth(altura); 
   cout << "Total Area del Paralelogramo de jose es: " << jose.getArea() << endl; ;

   Paralelogramo *Emanuel= new Paralelogramo() ;
   cout << "Ingrese la base: " << endl;
   cin >> base;
   cout << "Ingrese la altura: " << endl;
   cin >> altura;
   Emanuel->setHeight(base); 
   Emanuel->setWidth(altura);
   cout << "total Area del Paralelogramo de Emanuel es: " << Emanuel->getArea() << endl; ;

   return 0;
}