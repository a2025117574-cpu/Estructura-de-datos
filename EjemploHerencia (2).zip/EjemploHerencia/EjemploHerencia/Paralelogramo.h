#pragma once
#include "Shape.h"
class Paralelogramo : public Shape{
public: 


	int getArea() {
		return (width * height);
	}

};

